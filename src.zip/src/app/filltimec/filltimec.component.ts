import { Component } from '@angular/core';

@Component({
  selector: 'app-filltimec',
  templateUrl: './filltimec.component.html',
  styleUrls: ['./filltimec.component.css']
})
export class FilltimecComponent {

}
