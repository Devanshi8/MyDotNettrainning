import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilltimecComponent } from './filltimec.component';

describe('FilltimecComponent', () => {
  let component: FilltimecComponent;
  let fixture: ComponentFixture<FilltimecComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FilltimecComponent]
    });
    fixture = TestBed.createComponent(FilltimecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
