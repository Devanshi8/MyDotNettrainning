import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AttendenceComponent } from "./attendence/attendence.component";
import { LeaveComponent } from "./leave/leave.component";
import { FilltimecComponent } from "./filltimec/filltimec.component";

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'attendence',
    component: AttendenceComponent
  },
  {
    path: 'leave',
    component: LeaveComponent
  },
  {
    path: 'filltimec',
    component: FilltimecComponent
  }

  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
