export class UserData {
    userName: string = '';
    password: string = '';
    userType:number=0;
}